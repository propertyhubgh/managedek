<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <?php
if (! isset($_instance)) {
    $dom = \Livewire\Livewire::mount('dashboard-amount')->dom;
} elseif ($_instance->childHasBeenRendered('rkIPNS9')) {
    $componentId = $_instance->getRenderedChildComponentId('rkIPNS9');
    $componentTag = $_instance->getRenderedChildComponentTagName('rkIPNS9');
    $dom = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('rkIPNS9');
} else {
    $response = \Livewire\Livewire::mount('dashboard-amount');
    $dom = $response->dom;
    $_instance->logRenderedChild('rkIPNS9', $response->id, \Livewire\Livewire::getRootElementTagName($dom));
}
echo $dom;
?>









    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('multiauth::layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\managedek\resources\views/vendor/multiauth/admin/home.blade.php ENDPATH**/ ?>