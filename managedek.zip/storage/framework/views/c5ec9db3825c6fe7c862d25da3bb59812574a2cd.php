<?php $__env->startSection('content'); ?>

<div class="container">
    <hr>
    <a href="<?php echo e(route('idea.create')); ?>" class="btn btn-info btn-md">Add An Idea</a>
    <hr>
    <div class="card-deck">
        <?php $__currentLoopData = $ideas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $idea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card">
            <div class="card-body">
                <h5 class="card-title"><?php echo e($idea->name); ?></h5>
                <p class="card-text">
                    <?php echo e($idea->idea); ?>

                </p>
                <p class="card-text"><small class="text-muted"><?php echo e($idea->created_at->diffForHumans()); ?></small></p>
            </div>
        </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\managedek\resources\views/idea/index.blade.php ENDPATH**/ ?>