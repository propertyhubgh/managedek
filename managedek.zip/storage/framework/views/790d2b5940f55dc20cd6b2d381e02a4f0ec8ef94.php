<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <div class="row mb-5 align-content-around">
                <a href="<?php echo e(route('task.create')); ?>" class="btn btn-primary btn-md align-content-center">Create</a>
        </div>

    <table class="table table-hover">
        <thead>
        <tr>
            <th scope="col">#</th>
            <th scope="col">TITLE</th>
            <th scope="col">DESCRIPTION</th>
            <th scope="col">STATUS</th>
            <th scope="col">MODIFY</th>
        </tr>
        </thead>
        <tbody>
        <tr>
        <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th><?php echo e($task->id); ?></th>
                <td><?php echo e($task->title); ?></td>
                <td><?php echo e($task->description); ?></td>
                <td>
                    <?php if($task->status->type == 'pending'): ?>
                        <a href="#" class="badge badge-warning"><?php echo e($task->status->type); ?></a>
                    <?php endif; ?>
                    <?php if($task->status->type == 'halfway'): ?>
                        <a href="#" class="badge badge-info"><?php echo e($task->status->type); ?></a>
                    <?php endif; ?>
                    <?php if($task->status->type == 'completed'): ?>
                        <a href="#" class="badge badge-success"><?php echo e($task->status->type); ?></a>
                    <?php endif; ?>

                </td>
                <td>
                    <a href="<?php echo e(route('task.edit',$task->id)); ?>" class="badge badge-pill badge-info">Edit</a>
                    <form action="<?php echo e(route('task.destroy',$task->id)); ?>" method="post">
                        <?php echo method_field('DELETE'); ?>
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="badge badge-danger">Delete</button>
                    </form>

                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

        <?php echo e($tasks->links()); ?>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('vendor.multiauth.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\managedek\resources\views/admin/task/index.blade.php ENDPATH**/ ?>