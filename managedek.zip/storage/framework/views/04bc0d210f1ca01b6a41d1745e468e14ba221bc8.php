<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            

            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card-deck">
                <?php $__currentLoopData = $user->tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card">
                    <h5 class="card-title text-center pt-3"><?php echo e(strtoupper($task->title)); ?>

                        <br>
                        <?php if($task->status->type == 'pending'): ?>
                        <span class="badge badge-warning"><?php echo e($task->status->type); ?></span>
                        <?php elseif($task->status->type == 'completed'): ?>
                            <span class="badge badge-success"><?php echo e($task->status->type); ?></span>
                        <?php else: ?>
                            <span class="badge badge-info"><?php echo e($task->status->type); ?></span>
                        <?php endif; ?>
                    </h5>

                    <div class="card-body">
                        <p class="card-text">
                            <?php echo e($task->description); ?>

                        </p>
                    </div>
                    <div class="card-footer">
                        <small class="text-muted text-center"><?php echo e($task->date_assigned->diffForHumans()); ?></small>
                        <small class="text-muted text-center"><span>Start Time: </span><?php echo e(date('h:i:s A',strtotime($task->start_time))); ?></small>
                        <small class="text-muted text-center"><span>End Time: </span><?php echo e(date('h:i:s A',strtotime($task->end_time))); ?></small>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\managedek\resources\views/home.blade.php ENDPATH**/ ?>