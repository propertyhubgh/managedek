<?php return array (
  'dashboard-amount' => 'App\\Http\\Livewire\\DashboardAmount',
);